export const sum = (a, b) => a + b;

export const screamify = phrase => phrase.toUpperCase();